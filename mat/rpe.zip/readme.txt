Code Structure：
    - data: Stores network datasets before and after optimization

    - exp_results: Stores visualized experimental results
        - optimization_process: Visualization of the network optimization process

    - optim: Evolutionary algorithms

    - ml_models.py: Defines machine learning models
    - ml_feature_selection.py: Machine learning feature selection
    - ml_train_prediction.py: Machine learning model training and prediction

    - stat_optimization_value.py: Statistics on the degree of network robustness optimization
    - stat_prop_change.py: Statistics on changes in network properties before and after optimization (increase: unchanged: decrease)
    - stat_props_correlation.py: Correlation statistics between network properties and robustness
    - stat_random_rewiring.py: Statistics on changes in network robustness under random rewiring

    - visualization_degree_distribution.py: Degree distribution visualization
    - visualization_opt_process.py: Optimization process visualization
    - visualization_opt_typo.py: Visualization of network topology before and after optimization
    - visualization_tsne_visulization.py: TSNE dimensionality reduction visualization for different networks before and after optimization