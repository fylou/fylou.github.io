from networkx.algorithms.community import modularity, greedy_modularity_communities

from util_spectral_measure import *


def get_graph_props(graph: Union[nx.Graph, nx.DiGraph], props):
    """
    get graph-level properties of a graph

    Parameters
    ----------
    graph : input graph
    props : the properties

    Returns
    -------
    a list of graph properties

    """
    graph_props = []
    for p in props:
        if 'betweenness' == p:
            graph_props.append(sum(nx.betweenness_centrality(graph).values()) / len(graph))
        if 'clustering' == p:
            graph_props.append(sum(nx.clustering(graph).values()) / len(graph))
        if 'closeness' == p:
            graph_props.append(sum(nx.closeness_centrality(graph).values()) / len(graph))
        if 'eigenvector' == p:
            try:
                graph_props.append(sum(nx.eigenvector_centrality(graph).values()) / len(graph))
            except nx.exception.PowerIterationFailedConvergence:
                graph_props.append(np.nan)
        if 'katz' == p:
            try:
                graph_props.append(sum(nx.katz_centrality(graph).values()) / len(graph))
            except nx.exception.PowerIterationFailedConvergence:
                graph_props.append(np.nan)
        if 'pageRank' == p:
            graph_props.append(sum(nx.pagerank(graph).values()) / len(graph))
        if 'efficiency' == p:
            graph_props.append(nx.global_efficiency(graph))
        if 'girth' == p:
            cycles0 = list(nx.cycle_basis(graph))
            graph_props.append(max(3, min([len(cycle) for cycle in cycles0])))
        if 'max_cycle' == p:
            cycles0 = list(nx.cycle_basis(graph))
            graph_props.append(max([len(cycle) for cycle in cycles0]))
        if 'num_cycles' == p:
            cycles0 = list(nx.cycle_basis(graph))
            graph_props.append(len(cycles0))
        if 'assortativity' == p:
            graph_props.append(nx.degree_assortativity_coefficient(graph))
        if 'spectral_radius' == p:
            graph_props.append(spectral_radius(graph))
        if 'spectral_gap' == p:
            graph_props.append(spectral_gap(graph))
        if 'natural_connectivity' == p:
            graph_props.append(natural_connectivity(graph))
        if 'algebraic_connectivity' == p:
            graph_props.append(algebraic_connectivity(graph))
        if 'effective_resistance' == p:
            graph_props.append(effective_resistance(graph))
        if 'spanning_tree_count' == p:
            graph_props.append(spanning_tree_count(graph))

        # New Features
        if 'average_path_length' == p:
            if nx.is_connected(graph):
                graph_props.append(nx.average_shortest_path_length(graph))
            else:
                graph_props.append(np.nan)  # Not defined for disconnected graphs

        if 'network_diameter' == p:
            if nx.is_connected(graph):
                graph_props.append(nx.diameter(graph))
            else:
                graph_props.append(np.nan)  # Not defined for disconnected graphs

        if 'modularity' == p:
            communities = list(greedy_modularity_communities(graph))
            modularity_v = modularity(graph, communities)
            graph_props.append(modularity_v)

        if 'transitivity' == p:
            graph_props.append(nx.transitivity(graph))

    return graph_props
