# 机器学习模型
from time import time

from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_absolute_percentage_error
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn.svm import SVR


class MachineLearningModel:
    def __init__(self, model_name):
        self.model_name = model_name
        if model_name == 'svm':
            self.model = SVR()
        elif model_name == 'rf':
            self.model = RandomForestRegressor()
        elif model_name == 'mlp':
            self.model = MLPRegressor()
        elif model_name == 'knn':
            self.model = KNeighborsRegressor()
        else:
            raise NotImplementedError(f'{model_name}')

        self.imputer = SimpleImputer(strategy='mean')
        self.xscaler = MinMaxScaler()
        self.yscaler = None

    def fit(self, x, y):
        x = self.imputer.fit_transform(x)
        x = self.xscaler.fit_transform(x)
        self.model.fit(x, y)

    def predict(self, x_test, y_test):
        x_test = self.imputer.fit_transform(x_test)
        x_test = self.xscaler.fit_transform(x_test)

        net_pred, net_mape, net_mae = [], [], []
        tic = time()
        for i in range(len(y_test) // 100):
            y_pred = self.model.predict(x_test[i * 100:(i + 1) * 100])
            net_pred.append(y_pred)
            net_mae.append(mean_absolute_error(y_true=y_test[i * 100:(i + 1) * 100], y_pred=y_pred))
            net_mape.append(mean_absolute_percentage_error(y_true=y_test[i * 100:(i + 1) * 100], y_pred=y_pred))
        toc = time() - tic
        return net_mae, net_mape, net_pred, toc

    def predict_real(self, x_test, y_test):
        x_test = self.imputer.fit_transform(x_test)
        x_test = self.xscaler.fit_transform(x_test)
        y_pred = self.model.predict(x_test)
        mape = mean_absolute_percentage_error(y_true=y_test, y_pred=y_pred)
        mae = mean_absolute_error(y_true=y_test, y_pred=y_pred)

        return mae, mape, y_pred

    def score(self, x_test, y_test):
        x_test = self.imputer.fit_transform(x_test)
        x_test = self.xscaler.fit_transform(x_test)
        scores = []
        for i in range(len(y_test) // 100):
            score = self.model.score(x_test[i * 100:(i + 1) * 100], y_test[i * 100:(i + 1) * 100])
            scores.append(score)

        return scores
