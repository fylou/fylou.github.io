from matplotlib import pyplot as plt

plt.rcParams.update({'font.size': 14})
plt.rcParams.update({'font.family': 'Times New Roman'})
network_types = [
    'er',
    'qs',
    'ba',
    'sf',
    'eh',
    'rt',
    'rh',
    'ml',
    # 'so'
]

graph_props = [
    'betweenness',
    'clustering',
    'closeness',
    'eigenvector',
    'katz',
    'pageRank',
    'efficiency',
    # 'girth',
    'max_cycle',
    'num_cycles',
    'assortativity',
    'spectral_radius',
    'spectral_gap',
    'natural_connectivity',
    'algebraic_connectivity',
    'effective_resistance',
    'spanning_tree_count',
    'average_path_length',
    'network_diameter',
    'modularity',
    'transitivity',
]
