import numpy as np

from util_base_config import *

if __name__ == '__main__':
    networks = np.load('./data/dataset(1000).npy', allow_pickle=True).item()

    for net in network_types:
        g = networks['original_networks'][net]['graph']
        r = networks['original_networks'][net]['robustness']
        plt.axhline(r, color='r', linestyle='--', label=r'Initial R')

        gen_fits = networks['opt_process'][net]['generation_fitness']

        maxs = np.max(gen_fits, axis=1)
        mins = np.min(gen_fits, axis=1)
        std_devs = np.std(gen_fits, axis=1)

        x = np.arange(len(gen_fits))

        plt.plot(x, maxs, linestyle='--', label=f'Best R')
        #
        plt.fill_between(x, mins, maxs, alpha=0.2)
        # plt.boxplot(gen_fits)

        plt.xlabel('Generation')
        plt.ylabel('Robustness')
        plt.title(f'{net.upper()}')

        plt.legend(loc='best')

        plt.show()
        # plt.savefig(f'./exp_results/optimization_process/{net.upper()}.pdf', dpi=600)
        # plt.close()
