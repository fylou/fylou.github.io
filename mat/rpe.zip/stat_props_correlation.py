import numpy as np
from scipy.stats import pearsonr
from tqdm import tqdm

from util_base_config import *
from util_graph_property import get_graph_props
from optim.GA.utils import calculate_robustness

data_path = './data/dataset(200).npy'

if __name__ == '__main__':
    data = np.load(data_path, allow_pickle=True).item()
    for net in network_types:
        gs = data['opt_process'][net]['graphs']['graphs']
        print(net)
        for p in graph_props:
            props = [p]
            if p in data['opt_process'][net]['graphs'].keys():
                x = data['opt_process'][net]['graphs'][p]
            else:
                x = np.array([get_graph_props(g, props) for g in gs]).squeeze()
            data['opt_process'][net]['graphs'][p] = x

            mask = np.isnan(x)
            x = x[~mask]

            r = data['opt_process'][net]['graphs']['robustness_edge']
            # r = np.array([calculate_robustness(g) for g in tqdm(gs)]).squeeze()
            # data['opt_process'][net]['graphs']['robustness_edge'] = r
            r = r[~mask]
            try:
                corr, p_value = pearsonr(x, r)
            except ValueError:
                continue
            # plt.scatter(x, r)
            # plt.xlabel(p)
            # plt.ylabel('robustness')
            # plt.title(f'Pearson corr: {corr:.4f}')
            # plt.show()
            sig = '*' if p_value < 0.05 else ''
            print(f'{net}-{p}, {corr:.2f}{sig}')
    np.save(data_path, data)
