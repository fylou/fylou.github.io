import numpy as np

from util_base_config import *


if __name__ == '__main__':
    dataset = np.load('./data/dataset_with_props.npy', allow_pickle=True).item()
    for net in network_types:
        all_improve = []
        all_ori = []
        all_opt = []
        for i in range(1000):
            opt = dataset['optimized_networks'][net][i]['robustness']
            ori = dataset['original_networks'][net][i]['robustness']
            all_improve.append(opt - ori)
            all_ori.append(ori)
            all_opt.append(opt)
        print(f'{np.mean(all_ori):.4f}({np.std(all_ori):.4f})')
        print(f'{np.mean(all_opt):.4f}({np.std(all_opt):.4f})')
        print(f'{np.mean(all_improve):.4f}({np.std(all_improve):.4f})')
        print()
