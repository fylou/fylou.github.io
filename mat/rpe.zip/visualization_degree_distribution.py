import matplotlib.pyplot as plt
import networkx as nx
import numpy as np


if __name__ == '__main__':
    plt.rcParams.update({'font.size': 14})
    plt.rcParams.update({'font.family': 'Times New Roman'})
    network_types = [
        'er',
        'qs',
        'ba',
        'sf',
        'eh',
        'rt',
        'rh',
        'ml',
        'so'
    ]
    data = np.load('./data/dataset(1000).npy', allow_pickle=True).item()
    for net in network_types:
        g = data['original_networks'][net]['graph']

        hist = nx.degree_histogram(g)
        hist = [i / sum(hist) for i in hist]
        bins = range(len(hist))
        # 绘制直方图
        plt.bar(bins, hist, width=1, edgecolor='black')
        plt.title(f'{net.upper()}')
        plt.xlabel('Degree')
        plt.ylabel('Density')
        plt.show()
        # plt.savefig(f'./exp_results/degree_distribution/{net}.pdf', dpi=600)
        # plt.close()
