import time

import networkx as nx
import numpy as np
from tqdm import tqdm

from .population import Population
from .utils import calculate_robustness


def GA_example(graph, max_gen, max_rewire, p_cross, p_mutate, init_size, max_size, info='Optimization', verbose=1):
    Pop = Population(
        max_size=max_size,
        init_graph=graph,
        init_size=init_size,
        max_rewire=max_rewire,
        p_cross=p_cross,
        p_mutate=p_mutate
    )
    init_R = calculate_robustness(graph)
    all_best_ind = None
    all_gen_fits = []
    all_gen_inds = []
    if verbose == 'tqdm':
        iters = tqdm(range(max_gen), desc=info)
    elif verbose == 'print':
        iters = range(max_gen)
    else:
        raise NotImplementedError

    for gen in iters:
        Pop.crossover()
        Pop.mutate(graph)
        Pop.selection()
        gen_fits = [ind.fitness for ind in Pop.individuals]
        gen_inds = [ind.g for ind in Pop.individuals]
        best_ind = Pop.find_best()
        if gen == 0:
            all_best_ind = best_ind
        else:
            if best_ind.R > all_best_ind.R:
                all_best_ind = best_ind
        best_R = best_ind.R
        if verbose == 'print':
            print('\r', f'[{info}] Generation: {gen}, init_R: {init_R:.4f}, best_R: {best_R:.4f}', flush=True, end='')
        all_gen_fits.append(gen_fits)
        all_gen_inds.extend(gen_inds)
    all_graphs = {
        'fits':   np.array(all_gen_fits).reshape(-1),
        'graphs': all_gen_inds
    }
    assert [d for n, d in all_best_ind.g.degree()] == [d for n, d in graph.degree()]
    return all_graphs, all_gen_fits, all_best_ind.g
