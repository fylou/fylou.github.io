from copy import deepcopy

import networkx as nx


def calculate_robustness(graph):
    R = 0
    N = graph.number_of_nodes()
    G = deepcopy(graph)

    num_edges_to_remove = max(1, int(0.1 * G.number_of_edges()))

    for _ in range(N):
        if G.number_of_edges() == 0:
            break
        edge_betweenness = nx.edge_betweenness_centrality(G)
        sorted_edges = sorted(edge_betweenness.items(), key=lambda x: x[1], reverse=True)
        edges_to_remove = sorted_edges[:num_edges_to_remove]
        for edge, _ in edges_to_remove:
            G.remove_edge(*edge)
        if G.number_of_nodes() > 0:
            largest_cc = max(nx.connected_components(G), key=len)
        else:
            largest_cc = []
        R += float(len(largest_cc)) / N
    return R / N


def calculate_robustness_cheng(graph):
    R = 0
    N = graph.number_of_nodes()
    G = deepcopy(graph)
    for _ in range(N):
        degrees = dict(nx.degree(G))
        _node = max(degrees, key=degrees.get)
        G.remove_node(_node)
        if not nx.is_empty(G):
            largest_cc = max(nx.connected_components(G), key=len)
        else:
            largest_cc = []
        R = R + float(len(largest_cc)) / N
    return R / N


def calculate_robustness_wang(graph):
    R = 0
    N = graph.number_of_nodes()
    G_t = deepcopy(graph)
    for atk in range(N):
        deg = [G_t.degree(i) for i in range(N)]
        atk_ind = deg.index(max(deg))
        '''Get current node with largest degree'''
        dele = []
        for i in G_t[atk_ind]:
            dele.append(i)
        for i in dele:
            G_t.remove_edge(i, atk_ind)
        largest_cc = max(nx.connected_components(G_t), key=len)  # The largest connected component
        R = R + float(len(largest_cc)) / N
    return R / N
