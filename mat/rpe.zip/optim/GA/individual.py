from typing import Union

from .utils import *


class Individual:
    def __init__(self, graph: Union[nx.Graph, nx.DiGraph], fitness_measure=['robustness']):
        self.g = graph
        self.R = self.calculate_robustness()
        self.fitness = self.R

    def calculate_robustness(self):
        return calculate_robustness(self.g)
