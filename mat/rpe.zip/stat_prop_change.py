import numpy as np

from util_base_config import *

data = np.load('./data/dataset_with_props.npy', allow_pickle=True).item()
for prop in graph_props:
    print(prop)
    for net in network_types:
        ori_props, opt_props = [], []
        incre, decre, equal = 0, 0, 0
        nan_values = 0
        for i in range(1000):
            ori = data['original_networks'][net][i][prop]
            opt = data['optimized_networks'][net][i][prop]
            if prop in ['katz', 'eigenvector'] and (ori == -1 or opt == -1):
                nan_values += 1
                equal += 1
            else:
                if ori < opt:
                    incre += 1
                elif ori > opt:
                    decre += 1
                else:
                    equal += 1
                ori_props.append(ori)
                opt_props.append(opt)
        print(f'{np.mean(ori_props):.4f}, {np.mean(opt_props):.4f}, {incre}:{equal}:{decre}')
