import numpy as np
from sklearn.feature_selection import RFECV
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from tqdm import tqdm

from ml_models import MachineLearningModel

network_types = [
    'er',
    'qs',
    'ba',
    'sf',
    'eh',
    'rt',
    'rh',
    'ml',
    'so'
]

graph_props = [
    'betweenness',
    'clustering',
    'closeness',
    'eigenvector',
    'katz',
    'pageRank',
    'efficiency',
    # 'girth',
    'max_cycle',
    'num_cycles',
    'assortativity',
    'spectral_radius',
    'spectral_gap',
    'natural_connectivity',
    'algebraic_connectivity',
    'effective_resistance',
    'spanning_tree_count',
    'average_path_length',
    'network_diameter',
    'modularity',
    'transitivity',
]


def data_load(path='./data/dataset_with_props.npy'):
    data = np.load(path, allow_pickle=True).item()
    x_train, y_train = [], []
    x_test, y_test = [], []
    for net in network_types:
        for i in tqdm(range(900)):
            props = []
            for prop in graph_props:
                p = data['original_networks'][net][i][prop]
                # if p == -1:
                #     p = np.nan
                props.append(p)
            x_train.append(props)
            opt_r = data['optimized_networks'][net][i]['robustness'] - data['original_networks'][net][i]['robustness']
            y_train.append(abs(opt_r))

        for i in tqdm(range(900, 1000)):
            props = []
            for prop in graph_props:
                p = data['original_networks'][net][i][prop]
                # if p == -1:
                #     p = np.nan
                props.append(p)
            x_test.append(props)
            opt_r = data['optimized_networks'][net][i]['robustness'] - data['original_networks'][net][i]['robustness']
            y_test.append(abs(opt_r))

    return x_train, y_train, x_test, y_test


if __name__ == '__main__':
    models_type = ['rf']

    models = [MachineLearningModel(t) for t in models_type]

    print('loading dataset...')

    x_train, y_train, x_test, y_test = data_load('./data/dataset_with_props_edge.npy')

    imputer = SimpleImputer(strategy='mean')
    scaler = MinMaxScaler()
    x_train = imputer.fit_transform(x_train)
    x_train = scaler.fit_transform(x_train)
    x_test = imputer.fit_transform(x_test)
    x_test = scaler.fit_transform(x_test)

    for model in models:
        # 定义RFE选择器
        selector = RFECV(model.model, step=1, cv=5)

        # 拟合数据并选择最佳特征
        selector = selector.fit(x_train, y_train)

        # 打印选择的特征
        selected_features = [i for i, x in enumerate(selector.support_) if x]
        print("Selected features indices:", selected_features)

        # 打印特征名字
        selected_feature_names = [graph_props[i] for i in selected_features]
        print("Selected feature names:", selected_feature_names)
