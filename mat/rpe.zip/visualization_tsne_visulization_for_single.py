import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.manifold import TSNE
from sklearn.preprocessing import MinMaxScaler

from util_base_config import *


def tsne_visualization(X, y, net):
    scaler = MinMaxScaler()
    X = scaler.fit_transform(X)

    # 创建一个 t-SNE 实例
    tsne = TSNE(n_components=2)

    # 对数据进行 t-SNE 降维
    X_tsne = tsne.fit_transform(X)

    # 创建 DataFrame 来绘制 Seaborn 图
    tsne_df = pd.DataFrame(X_tsne, columns=['tsne1', 'tsne2'])
    tsne_df['label'] = y

    plt.rcParams.update({
        'font.size': 28,  # 全局字体大小
        # 'legend.fontsize': 22,  # 图例字体大小（放大标签）
    })

    # 绘制 t-SNE 可视化图
    plt.figure(figsize=(8, 6))

    # 使用 Seaborn 绘制图，并设置调色板增加对比度
    colors = ['blue', 'orange', 'green', 'red', 'purple', 'brown', 'pink', 'gray', 'olive', 'cyan']
    for n, cr in zip(network_types, colors):
        sns.scatterplot(data=tsne_df[
            tsne_df[
                'label'] == f'{n.upper()}'], x='tsne1', y='tsne2', marker='x', s=100, label=f'{n.upper()}', color=cr)
        sns.scatterplot(data=tsne_df[
            tsne_df[
                'label'] == f'{n.upper()}*'], x='tsne1', y='tsne2', marker='o', s=100, label=f'{n.upper()}*', color=cr)

    plt.xticks([])
    plt.yticks([])
    # 移动图例
    plt.legend()
    # plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.2), ncol=len(np.unique(y)) // 2)

    # plt.title('t-SNE Visualization')
    plt.xlabel('t-SNE d1')
    plt.ylabel('t-SNE d2')

    plt.tight_layout()
    # plt.show()
    plt.savefig(f'./exp_results/tsne_vis_{net}.pdf', dpi=600)
    plt.close()


if __name__ == "__main__":
    data = np.load('./data/dataset_with_props.npy', allow_pickle=True).item()

    network_types = [
        'er',
        'qs',
        'ba',
        'sf',
        'eh',
        'rt',
        'rh',
        'ml',
        # 'so'

    ]

    graph_props = [
        'betweenness',
        'clustering',
        'closeness',
        'eigenvector',
        'katz',
        'pageRank',
        'efficiency',
        # 'girth',
        'max_cycle',
        'num_cycles',
        'assortativity',
        'spectral_radius',
        'spectral_gap',
        'natural_connectivity',
        'algebraic_connectivity',
        'effective_resistance',
        'spanning_tree_count',
        'average_path_length',
        'network_diameter',
        'modularity',
        'transitivity',
    ]
    for net in network_types:
        X = []
        y = []
        for i in range(1000):
            ori_props_vec, opt_prop_vec = [], []
            nan_values = 0
            for prop in graph_props:
                ori = data['original_networks'][net][i][prop]
                opt = data['optimized_networks'][net][i][prop]
                ori_props_vec.append(ori)
                opt_prop_vec.append(opt)

            X.append(ori_props_vec)
            y.append(f'{net.upper()}')
            X.append(opt_prop_vec)
            y.append(f'{net.upper()}*')
        X = np.array(X)
        mean_value = np.nanmean(X)
        X[np.isnan(X)] = mean_value
        tsne_visualization(X, y, net)
