import networkx as nx
import numpy as np
from matplotlib import pyplot as plt

from util_base_config import network_types

if __name__ == '__main__':
    data = np.load('./data/dataset(1000).npy', allow_pickle=True).item()
    graphs = []
    # for net in network_types:
    #     graphs.append([data['original_networks'][net]['graph'], data['optimized_networks'][net]['graph']])
    print('load graphs.')
    for net in network_types:
        g0 = data['original_networks'][net]['graph']
        g1 = data['optimized_networks'][net]['graph']
        r0 = data['original_networks'][net]['robustness']
        r1 = data['optimized_networks'][net]['robustness']
        fig, axes = plt.subplots(1, 2, figsize=(10, 5))
        pos = nx.spring_layout(g0)
        nx.draw(g0, ax=axes[0], pos=pos, node_size=6)
        nx.draw(g1, ax=axes[1], pos=pos, node_size=6)
        plt.tight_layout()
        axes[0].set_title(f'original {net.upper()} network (R={r0:.3f})')
        axes[1].set_title(f'optimized {net.upper()} network (R={r1:.3f})')
        plt.tight_layout()
        plt.show()
        # plt.savefig(f'./exp_results/network_typology/{net.upper()}.pdf', dpi=500)
        # plt.close()
