import numpy as np
from tqdm import tqdm

from ml_models import MachineLearningModel

network_types = [
    'er',
    'qs',
    'ba',
    'sf',
    'eh',
    'rt',
    'rh',
    'ml',
    'so'
]

graph_props = [
    # 'betweenness',
    'clustering',
    # 'closeness',
    # 'eigenvector',
    # 'katz',
    # 'pageRank',
    # 'efficiency',
    # # 'girth',
    # 'max_cycle',
    # 'num_cycles',
    # 'assortativity',
    # 'spectral_radius',
    # 'spectral_gap',
    # 'natural_connectivity',
    # 'algebraic_connectivity',
    # 'effective_resistance',
    # 'spanning_tree_count',
    # 'average_path_length',
    # 'network_diameter',
    'modularity',
    'transitivity',
]


def data_load(path='./data/dataset_with_props.npy', label='diff'):
    data = np.load(path, allow_pickle=True).item()
    x_train, y_train = [], []
    x_test, y_test = [], []
    for net in network_types:
        for i in tqdm(range(900)):
            props = []
            for prop in graph_props:
                p = data['original_networks'][net][i][prop]
                if p == -1:
                    p = np.nan
                props.append(p)
            x_train.append(props)
            if label == 'diff':
                opt_r = data['optimized_networks'][net][i]['robustness'] - data['original_networks'][net][i][
                    'robustness']
            else:
                opt_r = data['optimized_networks'][net][i]['robustness']
            y_train.append(abs(opt_r))

        for i in tqdm(range(900, 1000)):
            props = []
            for prop in graph_props:
                p = data['original_networks'][net][i][prop]
                if p == -1:
                    p = np.nan
                props.append(p)
            x_test.append(props)
            if label == 'diff':
                opt_r = data['optimized_networks'][net][i]['robustness'] - data['original_networks'][net][i][
                    'robustness']
            else:
                opt_r = data['optimized_networks'][net][i]['robustness']
            y_test.append(abs(opt_r))

    return x_train, y_train, x_test, y_test


if __name__ == '__main__':
    models_type = ['rf', 'mlp', 'knn']

    models = [MachineLearningModel(t) for t in models_type]

    x_train, y_train, x_test, y_test = data_load('./data/dataset_with_props_edge.npy', label='diff')

    for model in models:
        model.fit(x_train, y_train)
        mae, mape, pred, time = model.predict(x_test, y_test)
        for m, mp in zip(mae, mape):
            print(f'{m:.6f}', end=',')
        print()
        print("预测时间：", time)
    print()
