from copy import deepcopy

import networkx as nx
import numpy as np
from tqdm import tqdm

from util_base_config import *
from optim.GA.utils import calculate_robustness


def random_rewiring(g, method='rewiring'):
    graph = deepcopy(g)
    if method == 'rewiring':
        g1 = nx.double_edge_swap(graph, nswap=5)
    else:
        raise NotImplementedError
    return g1


def get_fits():
    dataset = np.load('./data/dataset(1000).npy', allow_pickle=True).item()
    fits = {}
    for net in network_types:
        g = dataset['original_networks'][net]['graph']
        r = dataset['original_networks'][net]['robustness']
        rewired_gs = []
        for i in tqdm(range(1000), desc=f'random rewiring {net}'):
            g_i = random_rewiring(g, method='regenerate')
            rewired_gs.append(g_i)
        net_fits = [calculate_robustness(g) for g in tqdm(rewired_gs, desc=f'calculate robustness {net}')]
        fits.setdefault(net, net_fits)
    np.save(f'./res/random_rewiring_fits.npy', fits)


if __name__ == '__main__':
    get_fits()
