import json
import math
import os
import random
from copy import deepcopy

import networkx as nx
import numpy as np
import scipy.io as sio
from networkx.readwrite import json_graph


'''
=====================================
===== 1. Key computing function =====
=====================================
'''

# Computes betweenness centrality measure for given graph
# Takes networkx graph as input
def betweenness_centrality(graph):
    centrality_scores = nx.betweenness_centrality(graph, k=None)
    labelled_nodes = list(centrality_scores.items())

    return labelled_nodes


# Computes distance between nodes in a graph using djikstra's algorithm
def compute_distance(graph, vertex):
    distances = []
    shortest_path_lengths = nx.single_source_dijkstra_path_length(graph, vertex)
    distances = list(shortest_path_lengths.items())
    distances = sorted(distances, key=lambda x: x[1])

    return distances


# Computes average number of nodes (rounded down)
# for a set of given graphs
def compute_average_node_count(graphs):
    total = 0
    for graph in graphs:
        total += len(graph.nodes())
    average_nodes = total / len(graphs)

    return round(average_nodes)

'''
==============================
===== 2.read/write data  =====
==============================
'''
# load net data with R and node features from *.mat
# label: lc(connectivity robustness) or yc(controllability robustness)
#
def load_data(matpath, isd=1, label='lc'):
    mat = sio.loadmat(matpath)
    dataX = []
    dataY = []
    LENNET = mat['LENNET'][0][0]
    Rept = mat['Rept'][0][0]

    mat = mat['res']
    for i in range(LENNET):
        for j in range(int(Rept*0.6)):
            print(f'...loading the ({i},{j}) net...')
            adj = mat[i, j]['adj'][0, 0]
            if isd:  # directed net
                G = nx.from_numpy_matrix(adj, create_using=nx.DiGraph())
            else:  # undirected net
                G = nx.from_numpy_matrix(adj, create_using=nx.Graph())

            # assign attrs to every node
            feats_deg = mat[i, j]['deg'][0][0]
            feats_cc = mat[i, j]['cc'][0][0]
            # attrs = get_node_attr(G)
            for k in range(G.number_of_nodes()):
                attr = [feats_deg[k][0], feats_cc[k][0]]
                G.nodes[k]['node_attributes'] = attr

            # insert into results
            dataX.append(G)
            # tmpy = list(mat[i, j][label][0][0].T[0] / 1.0)
            dataY.append(mat[i, j][label][0][0].T[0] / 1.0)

    # data = zip(dataX, dataY)
    return dataX, dataY #list(data)


'''
-----Main-----
'''
if __name__ == '__main__':
    # for debug
    data = load_data('./data/LFR_both_N_dir1_wgt0_rnd.mat')
    print(len(data))
    print(type(data))
