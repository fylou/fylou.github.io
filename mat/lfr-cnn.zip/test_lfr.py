import argparse

import numpy as np
from tensorflow.python.keras.models import load_model
import util
from receptive_field import ReceptiveField
import random
import scipy.io as sio


class LFR_CNN_test():
    def __init__(self, w, modelpath, s=1, k=10, l='betweenness', attribute_name='node_attributes', num_attr=2):
        # Receptive field parameters
        self.w = w
        self.s = s
        self.k = k
        self.l = l
        self.attribute_name = attribute_name
        self.num_attr = num_attr
        self.model = self.init_model(modelpath)

        # Initializes the CNN

    # Convolutional layer channels depends on the number of attributes
    def init_model(self, modelpath):
        model = load_model(modelpath)
        model.summary()
        return model

    # Reshapes the data to fit the convolutional layer input shape
    # X - input graphs
    def process_data(self, X, num_attr):
        rf_tensors = []
        count = 0
        for g in X:
            count = count + 1
            print('fit->process_data: processing ' + str(count) + '/' + str(len(X)) + ' net...')
            rf = ReceptiveField(g,
                                w=self.w,
                                k=self.k,
                                s=self.s,
                                l=self.l,
                                attribute_name=self.attribute_name,
                                num_attr=self.num_attr)

            receptive_fields = rf.make_all_receptive_fields()
            # Reshape to (w*k, a_v)
            # rf_tensor = np.array(receptive_fields).flatten().reshape(self.w * self.k, num_attr)

            # tmp = np.array(random_delete(list(np.array(receptive_fields).flatten())))
            tmp = np.array(receptive_fields).flatten()
            rf_tensor = tmp.reshape(100, 100, 1)
            rf_tensors.append(rf_tensor)

        return np.array(rf_tensors)

    # Predict regression result
    def mypredict(self, X):
        X_tensors = self.process_data(X, self.num_attr)
        y_pred = self.model.predict(X_tensors)
        return y_pred


if __name__ == '__main__':
    # Training settings
    parser = argparse.ArgumentParser()
    parser.add_argument('--num_classes', type=int, default=21, help='regression length.')
    parser.add_argument('--num_attr', type=int, default=2, help='number of features.')
    parser.add_argument('--epoch', type=int, default=100, help='epochs.')
    parser.add_argument('--batch_size', type=int, default=8, help='batch size')

    parser.add_argument('--isd', type=int, default=1, help='directed network or undirected network')
    parser.add_argument('--label', type=str, default='lc', help='lc or yc')
    parser.add_argument('--w', type=int, default=500, help='parameter W in algorithm.')
    parser.add_argument('--model_path', type=str, default='./models/LFR_lc_N_dir0_wgt0_rnd.h5',
                        help='well trained models path')
    parser.add_argument('--test_path', type=str, default='./data/LFR_both_N_dir0_wgt0_rnd_test.mat',
                        help='test data path')
    parser.add_argument('--result_path', type=str, default='./results/LFR_lc_N_dir0_wgt0_rnd_pred.mat',
                        help='result name')

    args = parser.parse_args()

    # Load data
    X_test, Y_test = util.load_data(args.test_path, isd=args.isd, label=args.label)
    X_test = np.array(X_test)
    Y_test = np.array(Y_test) * 1000

    w = args.w
    psan = LFR_CNN_test(w, num_attr=args.num_attr, attribute_name='node_attributes', modelpath=args.model_path)
    pred = psan.mypredict(X_test)

    sio.savemat(args.resultname, {'pred': pred, 'sim': Y_test})
    print('test done!')
