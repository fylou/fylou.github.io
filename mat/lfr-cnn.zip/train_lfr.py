import argparse
import numpy as np
from lfr_cnn import LFR_CNN
import util


# Training settings
parser = argparse.ArgumentParser()
parser.add_argument('--num_classes', type=int, default=21, help='regression length.')
parser.add_argument('--num_attr', type=int, default=2, help='number of features.')
parser.add_argument('--epoch', type=int, default=100, help='epochs.')
parser.add_argument('--batch_size', type=int, default=8, help='batch size')
parser.add_argument('--valid_ratio', type=float, default=0.1,
                    help='ratio of validation data in all train data')
parser.add_argument('--isd', type=int, default=1, help='directed network or undirected network')
parser.add_argument('--label', type=str, default='lc', help='lc or yc')
parser.add_argument('--w', type=int, default=500, help='parameter W in algorithm.')
parser.add_argument('--train_path', type=str, default='./data/LFR_both_N_dir0_wgt0_rnd_train.mat',
                    help='train data path')
parser.add_argument('--test_path', type=str, default='./data/LFR_both_N_dir0_wgt0_rnd_test', help='test data path')
parser.add_argument('--result_path', type=str, default='./models/LFR_lc_N_dir0_wgt0_rnd.h5', help='result name')

args = parser.parse_args()


# Load data
X_train, Y_train = util.load_data(args.train_path, isd=args.isd, label=args.label)
Y_train = [[i] for i in Y_train]
X_train = np.array(X_train)

# Reduce floating point number
Y_train = np.array(Y_train) * 1000

# cal W
# w = util.compute_average_node_count(X_train)
w = args.w
print(f'w of dataset: {w}')


# establish modal
lfr = LFR_CNN(w, num_attr=args.num_attr, num_classes=args.num_classes, attribute_name='node_attributes', epochs=args.epoch,
                batch_size=args.batch_size)
# fit
lfr.fit(X_train, Y_train, valid=args.valid_ratio)
lfr.model.save(args.result_path)

