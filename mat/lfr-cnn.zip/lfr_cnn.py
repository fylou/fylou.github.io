import networkx as nx
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers

import util
from receptive_field import ReceptiveField
# from keras.wrappers.scikit_learn import KerasClassifier, KerasRegressor
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import *
import random


class LFR_CNN():
    def __init__(self, w, num_attr, s=1, k=10, l='betweenness',  # Patchy-San parameters
                 epochs=50, batch_size=8, optimizer='adam',  # CNN Parameters
                 attribute_name='node_attributes', num_classes=21):
        # Receptive field parameters
        self.w = w
        self.s = s
        self.k = k
        self.l = l
        self.attribute_name = attribute_name
        # CNN parameters
        self.num_classes = num_classes
        self.epochs = epochs
        self.batch_size = batch_size
        self.metrics = ['mse']
        self.optimizer = optimizer
        self.num_attr = num_attr
        self.model = self.init_model()  # KerasRegressor(build_fn=self.init_model,   epochs=self.epochs, batch_size=self.batch_size)

    # Initializes the CNN
    # Convolutional layer channels depends on the number of attributes 
    def init_model(self):
        model = Sequential()
        ####################################
        # cnn_1
        model.add(layers.Conv2D(64, (7, 7), activation='relu', input_shape=(100, 100, 1)))
        model.add(layers.MaxPooling2D((2, 2)))
        # cnn_2(94*94/2=47)
        model.add(layers.Conv2D(64, (5, 5), activation='relu'))
        model.add(layers.MaxPooling2D((2, 2)))
        # cnn_3(43*43/2=22)
        model.add(layers.Conv2D(128, (3, 3), activation='relu'))
        model.add(layers.MaxPooling2D((2, 2)))
        # flatten
        model.add(layers.Flatten())
        model.add(Dense(512, activation='relu'))
        model.add(Dense(1024, activation='relu'))
        # 21-Regression
        model.add(Dense(21, activation='relu'))

        model.compile(loss='mean_squared_error',
                      optimizer=self.optimizer,
                      metrics=self.metrics)
        model.summary()
        return model

    # Train models
    # Input data X should be in graph form
    def fit(self, X, y, valid=0.1):
        # Reshape input receptive fields
        X_tensors = self.process_data(X, self.num_attr)
        # X_valid_tensors=self.process_data(X_valid,self.num_attr)

        print("lfr.w:")
        print(self.w)
        self.model.fit(x=X_tensors, y=y,
                       batch_size=self.batch_size,
                       epochs=self.epochs,
                       validation_split=valid,
                       # validation_data=(X_valid_tensors, Y_valid),
                       shuffle=True,
                       verbose=1)

    # Reshapes the data to fit the convolutional layer input shape
    # X - input graphs
    def process_data(self, X, num_attr):
        rf_tensors = []
        count = 0
        for g in X:
            count = count + 1
            print('fit->process_data: processing ' + str(count) + '/' + str(len(X)) + ' net...')
            rf = ReceptiveField(g,
                                w=self.w,
                                k=self.k,
                                s=self.s,
                                l=self.l,
                                attribute_name=self.attribute_name,
                                num_attr=self.num_attr)

            receptive_fields = rf.make_all_receptive_fields()
            # Reshape to (w*k, a_v)
            # rf_tensor = np.array(receptive_fields).flatten().reshape(self.w * self.k, num_attr)
            # tmp = np.array(random_delete(list(np.array(receptive_fields).flatten())))
            tmp = np.array(receptive_fields).flatten()
            rf_tensor = tmp.reshape(100, 100, 1)	
            rf_tensors.append(rf_tensor)

        return np.array(rf_tensors)

    # Predict regression result
    def mypredict(self, X, y):
        X_tensors = self.process_data(X, self.num_attr)
        y_pred = self.model.predict(X_tensors)
        return y_pred


